==================== Files Description ==========================

dataGetter.py -

classifier.py -

preproccesData.py -

classify-final-build.pickle -


